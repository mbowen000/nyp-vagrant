/*****************************************************************************/
// File: main.m [scope = APPS/MACSHOW]
// Version: Kakadu, V7.4
// Author: David Taubman
// Last Revised: 13 May, 2014
/*****************************************************************************/
// Copyright 2001, David Taubman, The University of New South Wales (UNSW)
// The copyright owner is Unisearch Ltd, Australia (commercial arm of UNSW)
// Neither this copyright statement, nor the licensing details below
// may be removed from this file or dissociated from its contents.
/*****************************************************************************/
// Licensee: New York Philharmonic
// License number: 01521
// The licensee has been granted an EVALUATION license to the contents of
// this source file.  A brief summary of this license appears below.
// 1. The Licensee has the right to review and compile the Kakadu software
//    for the purpose of evaluating its potential and reporting that
//    potential to others, if desired.
// 2. The Licensee may release example source code which uses the Kakadu
//    software, but may not release the full Kakadu source code itself
//    or full applications which are built using the software.
// 3. The Licensee may not distribute re-usable code from which a complete
//    application can be built using the Kakadu software.
/******************************************************************************
 Description:
   Main entry point for the "kdu_macshow" application.
 ******************************************************************************/
#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
  return NSApplicationMain(argc,  (const char **) argv);  
}
